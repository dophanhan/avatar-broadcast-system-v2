# -*- coding: utf-8 -*-
"""
AI 数字人播报系统 - 阿里云函数计算后端 V8
修复：使用正确的 handler(event, context) 格式 + 处理 OPTIONS 预检
"""

import json
import hashlib
import hmac
import base64
from datetime import datetime
from urllib.parse import quote
import os

def handler(event, context):
    """阿里云函数计算 Python 3.10 正确格式"""
    
    # event 可能是 bytes 类型，需要解码
    if isinstance(event, bytes):
        event = event.decode('utf-8')
    if isinstance(event, str):
        event = json.loads(event)
    
    # 获取请求方法
    method = event.get('method', 'POST')
    
    # 处理 CORS 跨域（核心修复：响应 OPTIONS 预检请求）
    if method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Max-Age': '86400'
            },
            'body': ''
        }
    
    # 讯飞平台配置（从环境变量获取）
    API_KEY = os.environ.get('AVATAR_API_KEY', '')
    API_SECRET = os.environ.get('AVATAR_API_SECRET', '')
    APP_ID = os.environ.get('AVATAR_APP_ID', '')
    SCENE_ID = os.environ.get('AVATAR_SCENE_ID', '')
    WS_URL = "wss://avatar.cn-huadong-1.xf-yun.com/v1/interact"
    
    try:
        # 生成鉴权签名
        date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        signature_origin = f"host: avatar.cn-huadong-1.xf-yun.com\ndate: {date}\nGET /v1/interact HTTP/1.1"
        signature_sha = hmac.new(API_SECRET.encode(), signature_origin.encode(), digestmod=hashlib.sha256).digest()
        signature = base64.b64encode(signature_sha).decode()
        
        authorization_origin = f'api_key="{API_KEY}", algorithm="hmac-sha256", headers="host date request-line", signature="{signature}"'
        authorization = base64.b64encode(authorization_origin.encode()).decode()
        
        # 拼接完整签名地址
        signed_url = f"{WS_URL}?authorization={quote(authorization)}&date={quote(date)}&host=avatar.cn-huadong-1.xf-yun.com"
        
        # 获取前端参数
        body = event.get('body', '{}')
        # 如果 body 是 bytes，需要解码
        if isinstance(body, bytes):
            body = body.decode('utf-8')
        # 解析 JSON
        data = json.loads(body) if body else {}
        avatar_id = data.get("avatarId")
        vcn = data.get("vcn")
        full_text = data.get("fullText", "你好，欢迎使用数字人播报")
        
        # 文本拆分
        def split_text(text):
            sentences = []
            temp = ""
            for char in text:
                temp += char
                if char in "。！？；;\n！？":
                    sentences.append(temp.strip())
                    temp = ""
            if temp:
                sentences.append(temp.strip())
            return sentences
        
        speak_queue = split_text(full_text)
        
        # 返回结果（带 CORS 头）
        response = {
            "code": 0,
            "data": {
                "appId": APP_ID,
                "sceneId": SCENE_ID,
                "signedUrl": signed_url,
                "avatarId": avatar_id,
                "vcn": vcn,
                "speakQueue": speak_queue
            }
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps(response, ensure_ascii=False)
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({"code": -1, "msg": str(e)}, ensure_ascii=False)
        }
